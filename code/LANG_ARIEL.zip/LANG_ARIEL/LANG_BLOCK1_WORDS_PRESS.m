function LANG_BLOCK1_WORDS_PRESS()
% LANG_BLOCK1_WORDS_PRESS    

% Author: Ariel Tankus.
% Created: 31.01.2017.


filename_stimuli = 'params_murkamot_press';
lang_paradigm(filename_stimuli);
