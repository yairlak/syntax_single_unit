function LANG_BLOCK1_NONWORDS()
% LANG_BLOCK1_WORDS    

% Author: Ariel Tankus.
% Created: 31.01.2017.


filename_stimuli = 'params_nonwords';
lang_paradigm(filename_stimuli);
