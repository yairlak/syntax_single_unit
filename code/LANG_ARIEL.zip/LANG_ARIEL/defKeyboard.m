% Define Keyboard options

KbName('UnifyKeyNames');
returnKey  = KbName('space');
upKey    = KbName('UpArrow');
downKey  = KbName('DownArrow');
leftKey  = KbName('LeftArrow');
rightKey = KbName('RightArrow');
spaceKey = KbName('space');
altKey = KbName('LeftAlt');
controlKey = KbName('LeftControl');

exitKey  = KbName('ESCAPE');

LocationKey1 = KbName('1!');
LocationKey2 = KbName('2@');
LocationKey3 = KbName('3#');
LocationKey4 = KbName('4$');
LocationKey5 = KbName('5%');
LocationKey6 = KbName('6^');
LocationKey7 = KbName('7&');
LocationKey8 = KbName('8*');