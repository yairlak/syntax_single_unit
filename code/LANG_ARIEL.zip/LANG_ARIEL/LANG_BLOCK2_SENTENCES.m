function LANG_BLOCK2_SENTENCES()
% LANG_BLOCK2_SENTENCES    

% Author: Ariel Tankus.
% Created: 31.01.2017.


filename_stimuli = 'params_sentences';
lang_paradigm(filename_stimuli);
